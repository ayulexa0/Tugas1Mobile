package com.example.musicapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
